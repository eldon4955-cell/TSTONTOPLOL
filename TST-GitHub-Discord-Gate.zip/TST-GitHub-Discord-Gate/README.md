# TST Modding — GitHub Pages + Discord verification

This package separates the site frontend (GitHub Pages) from the Discord OAuth backend.

## 1. GitHub Pages

Upload **index.html** to your GitHub repository as exactly `index.html`.

In `index.html`, change:

`const API_BASE='https://YOUR-BACKEND.example.com';`

to your deployed backend URL, for example `https://tst-discord-gate.example.com`.

## 2. Discord Developer Portal

Create/use a Discord application and open its OAuth2 settings.

Add this exact redirect URI (matching your `.env`):

`https://YOUR-BACKEND-DOMAIN.example.com/auth/discord/callback`

The backend requests `identify` and `guilds`.

## 3. Backend environment variables

Copy `.env.example` to `.env` and fill in:

- `DISCORD_CLIENT_ID`
- `DISCORD_CLIENT_SECRET`
- `DISCORD_GUILD_ID` — your TST Discord server ID
- `DISCORD_REDIRECT_URI`
- `FRONTEND_URL`
- `SESSION_SECRET`

Do **not** put the client secret or session secret into GitHub Pages or `index.html`.

## 4. Deploy backend

This is a Node/Express backend and can be deployed on a Node host such as Render, Railway, Fly.io, or your own server.

Start command:

`npm start`

Health check:

`/health`

## 5. How the gate works

- If the backend session says the Discord account is a member of `DISCORD_GUILD_ID`, **CLICK TO CONTINUE** opens the site.
- If not authenticated, **JOIN & VERIFY DISCORD** starts Discord OAuth.
- Discord membership is checked server-side using the authenticated account's guild list.
- GitHub Pages never receives your Discord client secret.

## Important

A GitHub Pages-only site cannot securely determine who is logged into Discord or enforce server membership. The backend is required for the real check.
