TST MODDING — Discord-gated website

What changed:
- Visitors cannot enter the site until the server verifies that their Discord account is a member of the configured TST Discord server.
- Entrance still shows CLICK TO CONTINUE after verification.
- COOL PEOPLE has no profile pictures.
- COOL PEOPLE lists TST (Original Founder), TMR.BENVR (Second Founder), UnityModder (Third Founder), and Balloon Dog VR (Admin).

Setup:
1. Create/configure a Discord OAuth2 application in the Discord Developer Portal.
2. Add your site's callback URL: https://YOUR-DOMAIN.com/auth/discord/callback
3. Copy .env.example to .env.
4. Fill in DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, DISCORD_GUILD_ID, and DISCORD_REDIRECT_URI.
5. Use Node.js 18+ (20+ recommended).
6. Run: npm install
7. Run: npm start
8. Put the site behind HTTPS in production.

Important:
A static HTML page cannot securely prove Discord server membership by itself. This package uses a small server-side OAuth2 check so the gate cannot be bypassed just by changing localStorage or JavaScript in the browser.
