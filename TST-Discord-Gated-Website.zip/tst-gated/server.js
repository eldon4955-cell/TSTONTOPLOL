const express = require('express');
const session = require('express-session');
const crypto = require('crypto');
const path = require('path');
require('dotenv').config();

const app = express();
app.use(session({secret:process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex'),resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production'}}));
app.use(express.static(path.join(__dirname)));

const cfg={
 clientId:process.env.DISCORD_CLIENT_ID,
 clientSecret:process.env.DISCORD_CLIENT_SECRET,
 guildId:process.env.DISCORD_GUILD_ID,
 redirectUri:process.env.DISCORD_REDIRECT_URI
};
function configured(){return cfg.clientId&&cfg.clientSecret&&cfg.guildId&&cfg.redirectUri;}

app.get('/auth/discord',(req,res)=>{
 if(!configured()) return res.status(503).send('Discord verification is not configured yet. Set DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, DISCORD_GUILD_ID and DISCORD_REDIRECT_URI.');
 const state=crypto.randomBytes(24).toString('hex'); req.session.oauthState=state;
 const u=new URL('https://discord.com/oauth2/authorize');
 u.searchParams.set('client_id',cfg.clientId);u.searchParams.set('redirect_uri',cfg.redirectUri);u.searchParams.set('response_type','code');u.searchParams.set('scope','identify guilds');u.searchParams.set('state',state);
 res.redirect(u.toString());
});

app.get('/auth/discord/callback',async(req,res)=>{
 try{
  if(!configured()||!req.query.code||req.query.state!==req.session.oauthState) return res.status(400).send('Invalid Discord verification request.');
  const body=new URLSearchParams({client_id:cfg.clientId,client_secret:cfg.clientSecret,grant_type:'authorization_code',code:req.query.code,redirect_uri:cfg.redirectUri});
  const tokenRes=await fetch('https://discord.com/api/oauth2/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});
  if(!tokenRes.ok) throw new Error('Discord token exchange failed');
  const token=await tokenRes.json();
  const meRes=await fetch('https://discord.com/api/users/@me',{headers:{Authorization:`Bearer ${token.access_token}`}});
  const guildsRes=await fetch('https://discord.com/api/users/@me/guilds',{headers:{Authorization:`Bearer ${token.access_token}`}});
  if(!meRes.ok||!guildsRes.ok) throw new Error('Discord membership lookup failed');
  const me=await meRes.json(); const guilds=await guildsRes.json();
  const member=guilds.some(g=>g.id===cfg.guildId);
  req.session.discord={id:me.id,username:me.global_name||me.username,verified:member};
  delete req.session.oauthState;
  res.redirect('/?discord='+ (member?'verified':'not-member'));
 }catch(e){res.status(502).send('Discord verification failed. Please try again.');}
});

app.get('/api/verify',(req,res)=>res.json({verified:!!req.session.discord?.verified,user:req.session.discord||null}));
app.get('/logout',(req,res)=>req.session.destroy(()=>res.redirect('/')));

const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`TST gated site running on port ${port}`));
