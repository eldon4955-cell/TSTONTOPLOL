import { kv } from '@vercel/kv';

const KEY = 'tst:global:announcement';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'GET') {
    return res.status(200).json({ announcement: await kv.get(KEY) });
  }
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
  if (body.action === 'clear') {
    await kv.del(KEY);
    return res.status(200).json({ ok: true, announcement: null });
  }
  if (body.action === 'publish') {
    const message = String(body.message || '').trim();
    if (!message) return res.status(400).json({ error: 'Announcement is required' });
    const raw = Array.isArray(body.options) ? body.options.map(String).map(x=>x.trim()).filter(Boolean).slice(0,2) : [];
    const announcement = {
      message,
      author: String(body.author || 'TST').slice(0,40),
      createdAt: new Date().toISOString(),
      poll: raw.length === 2 ? { options: raw, counts: [0,0] } : null
    };
    await kv.set(KEY, announcement);
    return res.status(200).json({ ok: true, announcement });
  }
  if (body.action === 'vote') {
    const announcement = await kv.get(KEY);
    const i = Number(body.index);
    if (!announcement?.poll || !Number.isInteger(i) || i < 0 || i >= announcement.poll.options.length) {
      return res.status(400).json({ error: 'Invalid poll' });
    }
    announcement.poll.counts[i] = Number(announcement.poll.counts[i] || 0) + 1;
    await kv.set(KEY, announcement);
    return res.status(200).json({ ok: true, announcement });
  }
  return res.status(400).json({ error: 'Unknown action' });
}
